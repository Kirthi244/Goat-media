"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Sphere, MeshDistortMaterial, Float, Points, PointMaterial } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  BarChart3,
  Users,
  TrendingUp,
  UserCheck,
  Film,
  Calendar,
  Bell,
  X,
  DollarSign,
  Eye,
  LogOut,
  Lock,
  Plus,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  LineChart,
  Line,
} from "recharts"
import type * as THREE from "three"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"

function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null!)
  const particleCount = 1000

  const positions = new Float32Array(particleCount * 3)
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 20
    positions[i * 3 + 1] = (Math.random() - 0.5) * 20
    positions[i * 3 + 2] = (Math.random() - 0.5) * 20
  }

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.x = state.clock.elapsedTime * 0.05
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.075
    }
  })

  return (
    <Points ref={pointsRef} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial transparent color="#FFD700" size={0.02} sizeAttenuation={true} depthWrite={false} opacity={0.6} />
    </Points>
  )
}

function AnimatedBackground() {
  return (
    <div className="fixed inset-0 z-0">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-black animate-pulse" />
      <div
        className="absolute inset-0 bg-gradient-to-tr from-transparent via-yellow-500/5 to-transparent animate-pulse"
        style={{ animationDelay: "1s" }}
      />

      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-radial from-purple-500/30 to-transparent rounded-full blur-3xl animate-pulse" />
        <div
          className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-radial from-blue-500/30 to-transparent rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-radial from-yellow-500/20 to-transparent rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "3s" }}
        />
      </div>

      <Canvas camera={{ position: [0, 0, 5] }}>
        <ambientLight intensity={0.2} />
        <directionalLight position={[10, 10, 5]} intensity={0.4} />

        <Float speed={1.4} rotationIntensity={1} floatIntensity={2}>
          <Sphere args={[1, 100, 200]} position={[-4, -2, -5]}>
            <MeshDistortMaterial
              color="#8B5CF6"
              attach="material"
              distort={0.4}
              speed={2}
              roughness={0.2}
              transparent
              opacity={0.15}
            />
          </Sphere>
        </Float>
        <Float speed={1.75} rotationIntensity={1} floatIntensity={2}>
          <Sphere args={[0.8, 100, 200]} position={[4, 2, -3]}>
            <MeshDistortMaterial
              color="#06B6D4"
              attach="material"
              distort={0.5}
              speed={2.5}
              roughness={0.1}
              transparent
              opacity={0.12}
            />
          </Sphere>
        </Float>
        <Float speed={2} rotationIntensity={1} floatIntensity={1}>
          <Sphere args={[0.6, 100, 200]} position={[0, -4, -2]}>
            <MeshDistortMaterial
              color="#FFD700"
              attach="material"
              distort={0.3}
              speed={1.8}
              roughness={0.6}
              transparent
              opacity={0.1}
            />
          </Sphere>
        </Float>

        <ParticleField />

        <OrbitControls enableZoom={false} enablePan={false} enableRotate={false} />
      </Canvas>
    </div>
  )
}

function CursorFollower() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("mousemove", updateMousePosition)
    return () => window.removeEventListener("mousemove", updateMousePosition)
  }, [])

  return (
    <div
      className="fixed w-6 h-6 bg-gradient-to-br from-yellow-400/50 to-purple-500/50 rounded-full pointer-events-none z-50 mix-blend-difference blur-sm"
      style={{
        left: mousePosition.x - 12,
        top: mousePosition.y - 12,
        transition: "all 0.1s ease-out",
      }}
    />
  )
}

function PremiumCard({ children, className = "", hover3D = true, ...props }: any) {
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!hover3D || !cardRef.current) return

    const card = cardRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const centerX = rect.width / 2
      const centerY = rect.height / 2
      const rotateX = (y - centerY) / 10
      const rotateY = (centerX - x) / 10

      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`
    }

    const handleMouseLeave = () => {
      card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0px)"
    }

    card.addEventListener("mousemove", handleMouseMove)
    card.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      card.removeEventListener("mousemove", handleMouseMove)
      card.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [hover3D])

  return (
    <Card
      ref={cardRef}
      className={`
        bg-gradient-to-br from-zinc-900/80 via-zinc-800/60 to-zinc-900/80 
        border border-zinc-700/50 backdrop-blur-xl shadow-2xl
        hover:shadow-yellow-500/20 hover:shadow-2xl hover:border-yellow-500/30
        transition-all duration-500 ease-out
        relative overflow-hidden group
        ${className}
      `}
      style={{
        transformStyle: "preserve-3d",
        transition: "transform 0.3s ease-out, box-shadow 0.3s ease-out, border-color 0.3s ease-out",
      }}
      {...props}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm" />

      {children}
    </Card>
  )
}

function PremiumButton({ children, className = "", magnetic = true, ...props }: any) {
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!magnetic || !buttonRef.current) return

    const button = buttonRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const rect = button.getBoundingClientRect()
      const x = e.clientX - rect.left - rect.width / 2
      const y = e.clientY - rect.top - rect.height / 2

      button.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(1.05)`
    }

    const handleMouseLeave = () => {
      button.style.transform = "translate(0px, 0px) scale(1)"
    }

    button.addEventListener("mousemove", handleMouseMove)
    button.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      button.removeEventListener("mousemove", handleMouseMove)
      button.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [magnetic])

  return (
    <Button
      ref={buttonRef}
      className={`
        bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-semibold
        hover:from-yellow-500 hover:to-yellow-700 hover:shadow-lg hover:shadow-yellow-500/25
        active:scale-95 transition-all duration-200 ease-out
        relative overflow-hidden group
        ${className}
      `}
      style={{ transition: "transform 0.2s ease-out" }}
      {...props}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-transparent to-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-out" />
      {children}
    </Button>
  )
}

function AnimatedCounter({ value, duration = 2000 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    let startTime: number
    let animationFrame: number

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)

      setCount(Math.floor(progress * value))

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate)
      }
    }

    animationFrame = requestAnimationFrame(animate)

    return () => cancelAnimationFrame(animationFrame)
  }, [value, duration])

  return <span>{count}</span>
}

function SignInPage({ onSignIn }: { onSignIn: () => void }) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (username === "demo" && password === "demo") {
      onSignIn()
    } else {
      setError("Invalid credentials. Use username: demo, password: demo")
    }
  }

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center relative overflow-hidden">
      <AnimatedBackground />
      <CursorFollower />

      <div className="relative z-10 w-full max-w-md p-8">
        <PremiumCard className="transform hover:scale-105 transition-transform duration-500">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-yellow-500/25 animate-pulse">
              <Lock className="w-8 h-8 text-black" />
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              GOAT Media
            </CardTitle>
            <p className="text-gray-400">Premium Automation Hub</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-gray-300">Username</Label>
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-zinc-800/50 border-zinc-700 text-white placeholder-gray-400 focus:border-yellow-500/50 focus:ring-yellow-500/20 transition-all duration-300"
                  placeholder="Enter username"
                  required
                />
              </div>
              <div>
                <Label className="text-gray-300">Password</Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-zinc-800/50 border-zinc-700 text-white placeholder-gray-400 focus:border-yellow-500/50 focus:ring-yellow-500/20 transition-all duration-300"
                  placeholder="Enter password"
                  required
                />
              </div>
              {error && <p className="text-red-400 text-sm animate-pulse">{error}</p>}
              <PremiumButton type="submit" className="w-full">
                Sign In
              </PremiumButton>
            </form>
            <div className="mt-6 p-4 bg-zinc-800/30 rounded-lg border border-zinc-700 backdrop-blur-sm">
              <p className="text-xs text-gray-400 text-center">Demo Credentials:</p>
              <p className="text-xs text-yellow-400 text-center font-mono">demo / demo</p>
            </div>
          </CardContent>
        </PremiumCard>
      </div>
    </div>
  )
}

type PageType =
  | "dashboard"
  | "lead-management"
  | "sales-pipeline"
  | "team-management"
  | "content-studio"
  | "shoot-schedule"
  | "executive-view"

interface Lead {
  id: string
  company: string
  contact: string
  source: string
  budget: string
  status: "new" | "contacted" | "qualified" | "converted"
  nextAction: string
}

interface Deal {
  id: string
  company: string
  contact: string
  value: string
  priority: "high" | "medium" | "low"
  date: string
  stage: "prospecting" | "qualified" | "proposal" | "negotiation" | "closed-won"
}

interface TeamMember {
  name: string
  role: string
  status: "active" | "busy"
}

interface Team {
  name: string
  efficiency: string
  projects: string
  members: TeamMember[]
}

interface Shoot {
  id: string
  client: string
  type: string
  location: string
  time: string
  date: string
}

interface NotificationItem {
  id: string
  type: "shoot" | "content" | "sales" | "lead"
  message: string
  time: string
  priority: "high" | "medium" | "low"
}

interface DashboardStat {
  title: string
  value: string
  change: string
  icon: any
  color: string
}

interface PerformanceData {
  month: string
  revenue: number
  leads: number
}

const dashboardStats: DashboardStat[] = [
  {
    title: "Total Revenue",
    value: "₹2.4L",
    change: "+18%",
    icon: DollarSign,
    color: "text-green-400",
  },
  {
    title: "Active Clients",
    value: "36",
    change: "+12%",
    icon: Users,
    color: "text-blue-400",
  },
  {
    title: "Avg Deal Size",
    value: "₹1.4L",
    change: "+8.2%",
    icon: TrendingUp,
    color: "text-yellow-400",
  },
  {
    title: "Conversion Rate",
    value: "23.8%",
    change: "+5.1%",
    icon: UserCheck,
    color: "text-purple-400",
  },
]

const performanceData: PerformanceData[] = [
  { month: "Jan", revenue: 180000, leads: 45 },
  { month: "Feb", revenue: 220000, leads: 52 },
  { month: "Mar", revenue: 195000, leads: 48 },
  { month: "Apr", revenue: 240000, leads: 61 },
  { month: "May", revenue: 280000, leads: 55 },
  { month: "Jun", revenue: 320000, leads: 67 },
  { month: "Jul", revenue: 350000, leads: 58 },
  { month: "Aug", revenue: 248000, leads: 72 },
]

const notificationsData: NotificationItem[] = [
  {
    id: "1",
    type: "urgent",
    title: "Critical Alert",
    message: "Server maintenance required immediately",
    time: "10:30 AM",
  },
  {
    id: "2",
    type: "warning",
    title: "Low Inventory",
    message: "Stock levels for essential items are running low",
    time: "9:45 AM",
  },
  {
    id: "3",
    type: "info",
    title: "New Lead Assigned",
    message: "A new lead has been assigned to your team",
    time: "9:15 AM",
  },
  {
    id: "4",
    type: "success",
    title: "Report Generated",
    message: "The monthly performance report is now available",
    time: "8:30 AM",
  },
]

const MainApp = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [currentPage, setCurrentPage] = useState<PageType>("dashboard")

  const [isAddShootModalOpen, setIsAddShootModalOpen] = useState(false)
  const [isAddLeadModalOpen, setIsAddLeadModalOpen] = useState(false)
  const [isAddDealModalOpen, setIsAddDealModalOpen] = useState(false)
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false)
  const [showAnalytics, setShowAnalytics] = useState(false)
  const [analyticsType, setAnalyticsType] = useState<"leads" | "sales" | "team" | null>(null)
  const [showNotifications, setShowNotifications] = useState(false)
  const [generatedContent, setGeneratedContent] = useState("")
  const [currentDate, setCurrentDate] = useState(new Date())

  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null)

  const [leads, setLeads] = useState<Lead[]>([
    {
      id: "1",
      company: "TechStart Solutions",
      contact: "Rahul Sharma - CEO",
      source: "GOAT Mastermind",
      budget: "₹1.5L/month",
      status: "new",
      nextAction: "Shortlist Call",
    },
    {
      id: "2",
      company: "Digital Innovations",
      contact: "Priya Patel - CMO",
      source: "Social Media",
      budget: "₹1.2L/month",
      status: "contacted",
      nextAction: "Pitch Call",
    },
    {
      id: "3",
      company: "GrowthCorp",
      contact: "Sunita Verma - Director",
      source: "Kennet Alphy",
      budget: "₹2.1L/month",
      status: "qualified",
      nextAction: "Proposal",
    },
    {
      id: "4",
      company: "SuccessStory Ltd",
      contact: "Kavya Reddy - Marketing Head",
      source: "GOAT Mastermind",
      budget: "₹1.8L/month",
      status: "converted",
      nextAction: "Onboarding",
    },
  ])

  const [deals, setDeals] = useState<Deal[]>([
    {
      id: "1",
      company: "TechStart Solutions",
      contact: "Rahul Sharma - CEO",
      value: "₹85K",
      priority: "high",
      date: "Aug 20, 2025",
      stage: "prospecting",
    },
    {
      id: "2",
      company: "Digital Innovations",
      contact: "Priya Patel - CMO",
      value: "₹65K",
      priority: "medium",
      date: "Aug 22, 2025",
      stage: "prospecting",
    },
    {
      id: "3",
      company: "GrowthCorp",
      contact: "Sunita Verma - Director",
      value: "₹1.2L",
      priority: "high",
      date: "Aug 18, 2025",
      stage: "qualified",
    },
    {
      id: "4",
      company: "BrandBoost",
      contact: "Neha Gupta - Head of Marketing",
      value: "₹1.5L",
      priority: "high",
      date: "Aug 15, 2025",
      stage: "proposal",
    },
    {
      id: "5",
      company: "Enterprise Solutions",
      contact: "Rajesh Kumar - CEO",
      value: "₹2.1L",
      priority: "high",
      date: "Aug 12, 2025",
      stage: "negotiation",
    },
    {
      id: "6",
      company: "SuccessStory Ltd",
      contact: "Kavya Reddy - Marketing Head",
      value: "₹1.8L",
      priority: "high",
      date: "Aug 24, 2025",
      stage: "closed-won",
    },
  ])

  const [teams, setTeams] = useState<Team[]>([
    {
      name: "Del Team",
      efficiency: "94%",
      projects: "6 active projects",
      members: [
        { name: "Arjun Mehta", role: "Creative Director", status: "active" },
        { name: "Priya Sharma", role: "Project Manager", status: "busy" },
        { name: "Rahul Singh", role: "Video Editor", status: "active" },
        { name: "Neha Gupta", role: "Social Media Manager", status: "active" },
      ],
    },
    {
      name: "Centinals",
      efficiency: "97%",
      projects: "9 active projects",
      members: [
        { name: "Sanjay Kumar", role: "Creative Director", status: "active" },
        { name: "Kavya Reddy", role: "Project Manager", status: "active" },
        { name: "Amit Patel", role: "Video Editor", status: "busy" },
        { name: "Riya Agarwal", role: "Social Media Manager", status: "active" },
      ],
    },
    {
      name: "Alpha Team",
      efficiency: "91%",
      projects: "5 active projects",
      members: [
        { name: "Vikram Singh", role: "Creative Director", status: "active" },
        { name: "Sunita Verma", role: "Project Manager", status: "active" },
        { name: "Rohit Sharma", role: "Video Editor", status: "active" },
        { name: "Pooja Singh", role: "Social Media Manager", status: "busy" },
      ],
    },
  ])

  const [shoots, setShoots] = useState<Shoot[]>([
    {
      id: "1",
      client: "TechStart Solutions",
      type: "Brand Storytelling • Studio A",
      location: "Studio A",
      time: "11:00 AM",
      date: "2025-08-25",
    },
    {
      id: "2",
      client: "Digital Innovations",
      type: "Product Demo • Studio B",
      location: "Studio B",
      time: "3:00 PM",
      date: "2025-08-25",
    },
    {
      id: "3",
      client: "BrandBoost",
      type: "Interview Setup • Outdoor",
      location: "Outdoor",
      time: "6:00 PM",
      date: "2025-08-25",
    },
  ])

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: "1",
      type: "shoot",
      message: "TechStart Solutions shoot starting in 30 minutes",
      time: "10:30 AM",
      priority: "high",
    },
    {
      id: "2",
      type: "lead",
      message: "3 new leads awaiting qualification",
      time: "9:45 AM",
      priority: "medium",
    },
    {
      id: "3",
      type: "sales",
      message: "GrowthCorp deal moved to negotiation stage",
      time: "9:15 AM",
      priority: "medium",
    },
    {
      id: "4",
      type: "content",
      message: "5 scripts ready for review - Digital Innovations",
      time: "8:30 AM",
      priority: "low",
    },
  ])

  const showNotification = (message: string, type: "success" | "error" | "info" = "info") => {
    setNotification({ message, type })
    setTimeout(() => setNotification(null), 4000)
  }

  const leadsAnalyticsData = [
    { month: "Jan", leads: 45, converted: 12 },
    { month: "Feb", leads: 52, converted: 15 },
    { month: "Mar", leads: 48, converted: 14 },
    { month: "Apr", leads: 61, converted: 18 },
    { month: "May", leads: 55, converted: 16 },
    { month: "Jun", leads: 67, converted: 22 },
    { month: "Jul", leads: 58, converted: 19 },
    { month: "Aug", leads: 72, converted: 25 },
  ]

  const salesAnalyticsData = [
    { stage: "Prospecting", count: 8, value: 450000 },
    { stage: "Qualified", count: 5, value: 320000 },
    { stage: "Proposal", count: 3, value: 280000 },
    { stage: "Negotiation", count: 2, value: 180000 },
    { stage: "Closed Won", count: 4, value: 520000 },
  ]

  const teamPerformanceData = [
    { team: "Del Team", efficiency: 94, projects: 6, revenue: 180000 },
    { team: "Centinals", efficiency: 97, projects: 9, revenue: 250000 },
    { team: "Alpha Team", efficiency: 91, projects: 5, revenue: 150000 },
  ]

  const executiveData = {
    totalRevenue: "₹24.8L",
    monthlyGrowth: "+18.5%",
    activeClients: 36,
    avgDealSize: "₹1.4L",
    conversionRate: "23.8%",
    teamUtilization: "87%",
    monthlyRecurring: "₹18.2L",
    newRevenue: "₹6.6L",
  }

  const revenueChartData = [
    { month: "Jan", revenue: 180000, target: 200000 },
    { month: "Feb", revenue: 220000, target: 220000 },
    { month: "Mar", revenue: 195000, target: 210000 },
    { month: "Apr", revenue: 240000, target: 230000 },
    { month: "May", revenue: 280000, target: 250000 },
    { month: "Jun", revenue: 320000, target: 270000 },
    { month: "Jul", revenue: 350000, target: 300000 },
    { month: "Aug", revenue: 248000, target: 320000 },
  ]

  const clientRevenueData = [
    { name: "Enterprise Solutions", value: 210000, color: "#FFD700" },
    { name: "TechStart Solutions", value: 150000, color: "#FFA500" },
    { name: "BrandBoost", value: 120000, color: "#FF8C00" },
    { name: "GrowthCorp", value: 180000, color: "#FF7F50" },
    { name: "Others", value: 88000, color: "#FF6347" },
  ]

  const renderExecutiveView = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-semibold text-yellow-400">Executive Dashboard</h1>
          <p className="text-gray-400">Revenue Analytics & Business Intelligence</p>
        </div>
        <div className="flex items-center gap-2 bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-400 px-4 py-2 rounded-lg border border-green-500/30">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          Live Revenue Tracking
        </div>
      </div>

      {/* Revenue Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          {
            title: "Total Revenue",
            value: executiveData.totalRevenue,
            change: executiveData.monthlyGrowth,
            icon: DollarSign,
            color: "text-green-400",
          },
          {
            title: "Active Clients",
            value: executiveData.activeClients.toString(),
            change: "+12%",
            icon: Users,
            color: "text-blue-400",
          },
          {
            title: "Avg Deal Size",
            value: executiveData.avgDealSize,
            change: "+8.2%",
            icon: TrendingUp,
            color: "text-yellow-400",
          },
          {
            title: "Conversion Rate",
            value: executiveData.conversionRate,
            change: "+5.1%",
            icon: Eye,
            color: "text-purple-400",
          },
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card
              key={index}
              className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">{stat.title}</p>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className={`text-sm ${stat.color}`}>{stat.change}</p>
                  </div>
                  <div className={`p-3 rounded-full bg-gradient-to-br from-zinc-800 to-zinc-700 ${stat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Revenue Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400">Revenue vs Target</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1F2937",
                    border: "1px solid #374151",
                    borderRadius: "8px",
                  }}
                />
                <Area type="monotone" dataKey="target" stackId="1" stroke="#6B7280" fill="#6B7280" fillOpacity={0.3} />
                <Area type="monotone" dataKey="revenue" stackId="2" stroke="#FFD700" fill="#FFD700" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400">Revenue by Client</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={clientRevenueData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {clientRevenueData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => [`₹${(value / 1000).toFixed(0)}K`, "Revenue"]}
                  contentStyle={{
                    backgroundColor: "#1F2937",
                    border: "1px solid #374151",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400">Monthly Recurring Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{executiveData.monthlyRecurring}</div>
            <p className="text-green-400 text-sm">+15.2% from last month</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Retention Rate</span>
                <span className="text-white">94.5%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Churn Rate</span>
                <span className="text-white">5.5%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400">New Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{executiveData.newRevenue}</div>
            <p className="text-green-400 text-sm">+22.8% from last month</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">New Clients</span>
                <span className="text-white">8</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Upsells</span>
                <span className="text-white">₹2.1L</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-zinc-900/90 to-zinc-800/90 border-zinc-700/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400">Team Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{executiveData.teamUtilization}</div>
            <p className="text-yellow-400 text-sm">Optimal range: 80-90%</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Billable Hours</span>
                <span className="text-white">1,247h</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Efficiency Score</span>
                <span className="text-white">92%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const handleAddLead = (formData: FormData) => {
    const newLead: Lead = {
      id: (leads.length + 1).toString(),
      company: formData.get("company") as string,
      contact: formData.get("contact") as string,
      source: formData.get("source") as string,
      budget: formData.get("budget") as string,
      status: "new",
      nextAction: "Initial Contact",
    }
    setLeads([...leads, newLead])
    setIsAddLeadModalOpen(false)
    showNotification("Lead added successfully!", "success")
  }

  const handleAddDeal = (formData: FormData) => {
    const newDeal: Deal = {
      id: (deals.length + 1).toString(),
      company: formData.get("company") as string,
      contact: formData.get("contact") as string,
      value: formData.get("value") as string,
      priority: formData.get("priority") as "high" | "medium" | "low",
      date: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }),
      stage: "prospecting",
    }
    setDeals([...deals, newDeal])
    setIsAddDealModalOpen(false)
    showNotification("Deal added successfully!", "success")
  }

  const handleAddMember = (formData: FormData) => {
    const teamName = formData.get("team") as string
    const newMember: TeamMember = {
      name: formData.get("name") as string,
      role: formData.get("role") as string,
      status: "active",
    }

    setTeams(teams.map((team) => (team.name === teamName ? { ...team, members: [...team.members, newMember] } : team)))
    setIsAddMemberModalOpen(false)
    showNotification("Team member added successfully!", "success")
  }

  const handleAddShoot = (formData: FormData) => {
    const newShoot: Shoot = {
      id: (shoots.length + 1).toString(),
      client: formData.get("client") as string,
      type: `${formData.get("type")} • ${formData.get("location")}`,
      location: formData.get("location") as string,
      time: formData.get("time") as string,
      date: formData.get("date") as string,
    }
    setShoots([...shoots, newShoot])
    setIsAddShootModalOpen(false)
    showNotification("Shoot scheduled successfully!", "success")
  }

  const generateContent = () => {
    showNotification("Generating content pack...", "info")
    setTimeout(() => {
      const sampleContent = `🎯 CONTENT PACK GENERATED - TechStart Solutions

📝 SCRIPT 1: "The Hidden Cost of Manual Processes"
Hook: "Your team spends 40% of their time on tasks a robot could do..."
CTA: Book a free automation audit

📝 SCRIPT 2: "Why 90% of Startups Fail at Scaling"
Hook: "The difference between a ₹10L company and ₹1Cr company isn't what you think..."
CTA: Download our scaling blueprint

📝 SCRIPT 3: "The 3-Minute Rule That Doubled Our Productivity"
Hook: "If you can't explain your process in 3 minutes, it's broken..."
CTA: Get our process optimization checklist

📝 SCRIPT 4: "From Chaos to System: A Real Transformation"
Hook: "6 months ago, this CEO was working 80-hour weeks..."
CTA: Watch the full case study

📝 SCRIPT 5: "The Automation Myth That's Costing You Money"
Hook: "Everyone thinks automation is expensive. Here's the truth..."
CTA: Calculate your automation ROI

✅ All scripts include:
- Platform-specific formatting (IG/YT/FB)
- B-roll suggestions
- Engagement hooks
- Clear CTAs aligned with funnel stage
- Brand voice consistency check passed`

      setGeneratedContent(sampleContent)
      showNotification("Content pack generated successfully! 5 scripts ready for review.", "success")
    }, 3000)
  }

  const navigateDate = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate)
    if (direction === "prev") {
      newDate.setMonth(newDate.getMonth() - 1)
    } else {
      newDate.setMonth(newDate.getMonth() + 1)
    }
    setCurrentDate(newDate)
  }

  const formatMonth = (date: Date) => {
    return date.toLocaleDateString("en-US", { month: "long", year: "numeric" })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-pink-500/20 text-pink-400"
      case "contacted":
        return "bg-yellow-500/20 text-yellow-400"
      case "qualified":
        return "bg-blue-500/20 text-blue-400"
      case "converted":
        return "bg-green-500/20 text-green-400"
      case "active":
        return "bg-green-500/20 text-green-400"
      case "busy":
        return "bg-yellow-500/20 text-yellow-400"
      case "high":
        return "bg-red-500/20 text-red-400"
      case "medium":
        return "bg-yellow-500/20 text-yellow-400"
      case "low":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-gray-500/20 text-gray-400"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500/20 text-red-400"
      case "medium":
        return "bg-yellow-500/20 text-yellow-400"
      case "low":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-gray-500/20 text-gray-400"
    }
  }

  const renderDashboard = () => (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Dashboard Overview
          </h2>
          <p className="text-gray-400 mt-1">Real-time insights and performance metrics</p>
        </div>
        <div className="flex gap-3">
          <PremiumButton className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
            <Eye className="w-4 h-4 mr-2" />
            Live View
          </PremiumButton>
        </div>
      </div>

      <PremiumCard className="mb-6">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Real-time Notifications & Next Tasks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {notificationsData.map((notification, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg border-l-4 backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] ${
                  notification.type === "urgent"
                    ? "bg-red-900/20 border-l-red-500 hover:bg-red-900/30"
                    : notification.type === "warning"
                      ? "bg-yellow-900/20 border-l-yellow-500 hover:bg-yellow-900/30"
                      : "bg-blue-900/20 border-l-blue-500 hover:bg-blue-900/30"
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-white">{notification.title}</p>
                    <p className="text-sm text-gray-400">{notification.message}</p>
                  </div>
                  <span className="text-xs text-gray-500">{notification.time}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </PremiumCard>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {dashboardStats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <PremiumCard
              key={index}
              className="group cursor-pointer transform hover:scale-105 transition-all duration-500"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm group-hover:text-gray-300 transition-colors">{stat.title}</p>
                    <p className="text-2xl font-bold text-white group-hover:text-yellow-400 transition-colors">
                      <AnimatedCounter value={Number.parseInt(stat.value.replace(/[^0-9]/g, ""))} />
                      {stat.value.replace(/[0-9]/g, "")}
                    </p>
                    <p className={`text-sm ${stat.color} group-hover:brightness-110 transition-all`}>{stat.change}</p>
                  </div>
                  <div
                    className={`p-3 rounded-full bg-gradient-to-br from-zinc-800 to-zinc-700 ${stat.color} group-hover:scale-110 group-hover:rotate-12 transition-all duration-300`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </PremiumCard>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PremiumCard>
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Performance Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={performanceData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFD700" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#FFD700" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(31, 41, 55, 0.95)",
                    border: "1px solid #374151",
                    borderRadius: "12px",
                    backdropFilter: "blur(10px)",
                    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#FFD700"
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                  strokeWidth={3}
                />
                <Area
                  type="monotone"
                  dataKey="leads"
                  stroke="#8B5CF6"
                  fillOpacity={1}
                  fill="url(#colorLeads)"
                  strokeWidth={3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </PremiumCard>

        <PremiumCard>
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Team Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={teamPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="team" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(31, 41, 55, 0.95)",
                    border: "1px solid #374151",
                    borderRadius: "12px",
                    backdropFilter: "blur(10px)",
                    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                  }}
                />
                <Bar dataKey="efficiency" fill="url(#barGradient)" radius={[4, 4, 0, 0]} />
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#FFD700" />
                    <stop offset="100%" stopColor="#F59E0B" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </PremiumCard>
      </div>
    </div>
  )

  const renderLeadManagement = () => (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Lead Management
          </h2>
          <p className="text-gray-400 mt-1">Track and manage your sales leads</p>
        </div>
        <div className="flex gap-3">
          <PremiumButton
            onClick={() => {
              setAnalyticsType("leads")
              setShowAnalytics(true)
            }}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </PremiumButton>
          <Dialog open={isAddLeadModalOpen} onOpenChange={setIsAddLeadModalOpen}>
            <DialogTrigger asChild>
              <PremiumButton>
                <Plus className="w-4 h-4 mr-2" />
                Add Lead
              </PremiumButton>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900/95 border-zinc-700/50 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="text-yellow-400">Add New Lead</DialogTitle>
              </DialogHeader>
              <form action={handleAddLead} className="space-y-4">
                <div>
                  <Label className="text-gray-300">Company Name</Label>
                  <Input
                    name="company"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="Enter company name"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Contact Person</Label>
                  <Input
                    name="contact"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="Name - Position"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Source</Label>
                  <Select name="source" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="GOAT Mastermind">GOAT Mastermind</SelectItem>
                      <SelectItem value="Social Media">Social Media</SelectItem>
                      <SelectItem value="Kennet Alphy">Kennet Alphy</SelectItem>
                      <SelectItem value="Alfred Joshua">Alfred Joshua</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-300">Budget</Label>
                  <Input
                    name="budget"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="₹1.5L/month"
                    required
                  />
                </div>
                <PremiumButton type="submit" className="w-full">
                  Add Lead
                </PremiumButton>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {showAnalytics && analyticsType === "leads" && (
        <PremiumCard className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-yellow-400">Lead Analytics</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAnalytics(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Lead Conversion Trend</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={leadsAnalyticsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="month" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(31, 41, 55, 0.95)",
                        border: "1px solid #374151",
                        borderRadius: "12px",
                        backdropFilter: "blur(10px)",
                      }}
                    />
                    <Line type="monotone" dataKey="leads" stroke="#8B5CF6" strokeWidth={3} />
                    <Line type="monotone" dataKey="converted" stroke="#FFD700" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Lead Sources</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: "GOAT Mastermind", value: 45, color: "#FFD700" },
                        { name: "Social Media", value: 25, color: "#8B5CF6" },
                        { name: "Kennet Alphy", value: 20, color: "#06B6D4" },
                        { name: "Alfred Joshua", value: 10, color: "#F59E0B" },
                      ]}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {[
                        { name: "GOAT Mastermind", value: 45, color: "#FFD700" },
                        { name: "Social Media", value: 25, color: "#8B5CF6" },
                        { name: "Kennet Alphy", value: 20, color: "#06B6D4" },
                        { name: "Alfred Joshua", value: 10, color: "#F59E0B" },
                      ].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
      )}

      <div className="grid gap-4">
        {leads.map((lead, index) => (
          <PremiumCard key={lead.id} style={{ animationDelay: `${index * 100}ms` }}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-white">{lead.company}</h3>
                    <Badge className={`${getStatusColor(lead.status)} border-0`}>{lead.status}</Badge>
                  </div>
                  <p className="text-gray-400 mb-1">{lead.contact}</p>
                  <p className="text-sm text-gray-500">Source: {lead.source}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-yellow-400">{lead.budget}</p>
                  <p className="text-sm text-gray-400">Next: {lead.nextAction}</p>
                </div>
              </div>
            </CardContent>
          </PremiumCard>
        ))}
      </div>
    </div>
  )

  const renderSalesPipeline = () => (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Sales Pipeline
          </h2>
          <p className="text-gray-400 mt-1">Track deals through your sales process</p>
        </div>
        <div className="flex gap-3">
          <PremiumButton
            onClick={() => {
              setAnalyticsType("sales")
              setShowAnalytics(true)
            }}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </PremiumButton>
          <Dialog open={isAddDealModalOpen} onOpenChange={setIsAddDealModalOpen}>
            <DialogTrigger asChild>
              <PremiumButton>
                <Plus className="w-4 h-4 mr-2" />
                Add Deal
              </PremiumButton>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900/95 border-zinc-700/50 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="text-yellow-400">Add New Deal</DialogTitle>
              </DialogHeader>
              <form action={handleAddDeal} className="space-y-4">
                <div>
                  <Label className="text-gray-300">Company Name</Label>
                  <Input
                    name="company"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="Enter company name"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Contact Person</Label>
                  <Input
                    name="contact"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="Name - Position"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Deal Value</Label>
                  <Input
                    name="value"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="₹1.5L"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Priority</Label>
                  <Select name="priority" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <PremiumButton type="submit" className="w-full">
                  Add Deal
                </PremiumButton>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {showAnalytics && analyticsType === "sales" && (
        <PremiumCard className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-yellow-400">Sales Analytics</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAnalytics(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Pipeline Stage Analysis</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={salesAnalyticsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="stage" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(31, 41, 55, 0.95)",
                        border: "1px solid #374151",
                        borderRadius: "12px",
                        backdropFilter: "blur(10px)",
                      }}
                    />
                    <Bar dataKey="count" fill="#FFD700" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Revenue by Stage</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={salesAnalyticsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="stage" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(31, 41, 55, 0.95)",
                        border: "1px solid #374151",
                        borderRadius: "12px",
                        backdropFilter: "blur(10px)",
                      }}
                    />
                    <Area type="monotone" dataKey="value" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
      )}

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {["prospecting", "qualified", "proposal", "negotiation", "closed-won"].map((stage) => (
          <div key={stage} className="space-y-4">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white capitalize mb-1">{stage.replace("-", " ")}</h3>
              <p className="text-sm text-gray-400">{deals.filter((deal) => deal.stage === stage).length} deals</p>
            </div>
            <div className="space-y-3 min-h-[400px]">
              {deals
                .filter((deal) => deal.stage === stage)
                .map((deal, index) => (
                  <PremiumCard
                    key={deal.id}
                    className="cursor-move hover:scale-105 transition-transform duration-200"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-white text-sm">{deal.company}</h4>
                          <Badge className={`${getPriorityColor(deal.priority)} border-0 text-xs`}>
                            {deal.priority}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-400">{deal.contact}</p>
                        <div className="flex justify-between items-center">
                          <span className="text-yellow-400 font-semibold">{deal.value}</span>
                          <span className="text-xs text-gray-500">{deal.date}</span>
                        </div>
                      </div>
                    </CardContent>
                  </PremiumCard>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )

  const renderTeamManagement = () => (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Team Management
          </h2>
          <p className="text-gray-400 mt-1">Monitor team performance and manage members</p>
        </div>
        <div className="flex gap-3">
          <PremiumButton
            onClick={() => {
              setAnalyticsType("team")
              setShowAnalytics(true)
            }}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Performance Report
          </PremiumButton>
          <Dialog open={isAddMemberModalOpen} onOpenChange={setIsAddMemberModalOpen}>
            <DialogTrigger asChild>
              <PremiumButton>
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </PremiumButton>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900/95 border-zinc-700/50 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="text-yellow-400">Add Team Member</DialogTitle>
              </DialogHeader>
              <form action={handleAddMember} className="space-y-4">
                <div>
                  <Label className="text-gray-300">Team</Label>
                  <Select name="team" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select team" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="Del Team">Del Team</SelectItem>
                      <SelectItem value="Centinals">Centinals</SelectItem>
                      <SelectItem value="Alpha Team">Alpha Team</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-300">Name</Label>
                  <Input
                    name="name"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    placeholder="Enter member name"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Role</Label>
                  <Select name="role" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="Creative Director">Creative Director</SelectItem>
                      <SelectItem value="Project Manager">Project Manager</SelectItem>
                      <SelectItem value="Video Editor">Video Editor</SelectItem>
                      <SelectItem value="Social Media Manager">Social Media Manager</SelectItem>
                      <SelectItem value="Designer">Designer</SelectItem>
                      <SelectItem value="Videographer">Videographer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <PremiumButton type="submit" className="w-full">
                  Add Member
                </PremiumButton>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {showAnalytics && analyticsType === "team" && (
        <PremiumCard className="mb-6">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-yellow-400">Team Performance Analytics</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAnalytics(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Team Efficiency</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={teamPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="team" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(31, 41, 55, 0.95)",
                        border: "1px solid #374151",
                        borderRadius: "12px",
                        backdropFilter: "blur(10px)",
                      }}
                    />
                    <Bar dataKey="efficiency" fill="#FFD700" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Revenue by Team</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={teamPerformanceData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="revenue"
                      label={({ team, percent }) => `${team} ${(percent * 100).toFixed(0)}%`}
                    >
                      {teamPerformanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={["#FFD700", "#8B5CF6", "#06B6D4"][index]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => [`₹${(value / 1000).toFixed(0)}K`, "Revenue"]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
      )}

      <div className="grid gap-6">
        {teams.map((team, index) => (
          <PremiumCard key={team.name} style={{ animationDelay: `${index * 100}ms` }}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-yellow-400">{team.name}</CardTitle>
                  <p className="text-gray-400">{team.projects}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-white">{team.efficiency}</div>
                  <p className="text-sm text-gray-400">Efficiency</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {team.members.map((member, memberIndex) => (
                  <div
                    key={memberIndex}
                    className="p-4 bg-zinc-800/50 rounded-lg border border-zinc-700/50 hover:border-yellow-500/30 transition-all duration-300"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-white">{member.name}</h4>
                      <Badge className={`${getStatusColor(member.status)} border-0`}>{member.status}</Badge>
                    </div>
                    <p className="text-sm text-gray-400">{member.role}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </PremiumCard>
        ))}
      </div>
    </div>
  )

  const renderContentStudio = () => (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Content Studio
          </h2>
          <p className="text-gray-400 mt-1">AI-powered content generation and management</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PremiumCard>
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <Film className="w-5 h-5" />
              AI Content Generator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Client/Brand</Label>
              <Select>
                <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="techstart">TechStart Solutions</SelectItem>
                  <SelectItem value="digital">Digital Innovations</SelectItem>
                  <SelectItem value="growth">GrowthCorp</SelectItem>
                  <SelectItem value="brand">BrandBoost</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Content Type</Label>
              <Select>
                <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                  <SelectValue placeholder="Select content type" />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="awareness">Awareness Content</SelectItem>
                  <SelectItem value="conversion">Conversion Content</SelectItem>
                  <SelectItem value="mixed">Mixed Pack (5+5)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-gray-300">Target Platform</Label>
              <Select>
                <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="instagram">Instagram Reels</SelectItem>
                  <SelectItem value="youtube">YouTube Shorts</SelectItem>
                  <SelectItem value="facebook">Facebook Reels</SelectItem>
                  <SelectItem value="all">All Platforms</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <PremiumButton onClick={generateContent} className="w-full">
              <Film className="w-4 h-4 mr-2" />
              Generate Content Pack
            </PremiumButton>
          </CardContent>
        </PremiumCard>

        <PremiumCard>
          <CardHeader>
            <CardTitle className="text-yellow-400">Content Workflow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { stage: "Script Generation", status: "completed", count: 5 },
                { stage: "Review & Approval", status: "in-progress", count: 3 },
                { stage: "Shoot Planning", status: "pending", count: 2 },
                { stage: "Post Production", status: "pending", count: 0 },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-zinc-800/50 rounded-lg border border-zinc-700/50"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        item.status === "completed"
                          ? "bg-green-400"
                          : item.status === "in-progress"
                            ? "bg-yellow-400 animate-pulse"
                            : "bg-gray-400"
                      }`}
                    />
                    <span className="text-white">{item.stage}</span>
                  </div>
                  <Badge className="bg-zinc-700/50 text-gray-300 border-0">{item.count} items</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </PremiumCard>
      </div>

      {generatedContent && (
        <PremiumCard className="animate-in slide-in-from-bottom duration-500">
          <CardHeader>
            <CardTitle className="text-yellow-400">Generated Content Pack</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={generatedContent}
              readOnly
              className="min-h-[400px] bg-zinc-800/50 border-zinc-700 text-white font-mono text-sm resize-none"
            />
            <div className="flex gap-3 mt-4">
              <PremiumButton className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                Approve Content
              </PremiumButton>
              <Button
                variant="outline"
                className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10 bg-transparent"
              >
                Request Revisions
              </Button>
            </div>
          </CardContent>
        </PremiumCard>
      )}
    </div>
  )

  const renderShootSchedule = () => (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
            Shoot Schedule
          </h2>
          <p className="text-gray-400 mt-1">Manage video shoots and production calendar</p>
        </div>
        <div className="flex gap-3">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigateDate("prev")}
              className="border-zinc-700 text-gray-400 hover:text-white hover:border-yellow-500/50"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-white font-semibold px-4">{formatMonth(currentDate)}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigateDate("next")}
              className="border-zinc-700 text-gray-400 hover:text-white hover:border-yellow-500/50"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <Dialog open={isAddShootModalOpen} onOpenChange={setIsAddShootModalOpen}>
            <DialogTrigger asChild>
              <PremiumButton>
                <Plus className="w-4 h-4 mr-2" />
                Add Shoot
              </PremiumButton>
            </DialogTrigger>
            <DialogContent className="bg-zinc-900/95 border-zinc-700/50 backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="text-yellow-400">Schedule New Shoot</DialogTitle>
              </DialogHeader>
              <form action={handleAddShoot} className="space-y-4">
                <div>
                  <Label className="text-gray-300">Client</Label>
                  <Select name="client" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select client" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="TechStart Solutions">TechStart Solutions</SelectItem>
                      <SelectItem value="Digital Innovations">Digital Innovations</SelectItem>
                      <SelectItem value="GrowthCorp">GrowthCorp</SelectItem>
                      <SelectItem value="BrandBoost">BrandBoost</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-300">Shoot Type</Label>
                  <Select name="type" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select shoot type" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="Brand Storytelling">Brand Storytelling</SelectItem>
                      <SelectItem value="Product Demo">Product Demo</SelectItem>
                      <SelectItem value="Interview Setup">Interview Setup</SelectItem>
                      <SelectItem value="Testimonial">Testimonial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-300">Location</Label>
                  <Select name="location" required>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800 border-zinc-700">
                      <SelectItem value="Studio A">Studio A</SelectItem>
                      <SelectItem value="Studio B">Studio B</SelectItem>
                      <SelectItem value="Outdoor">Outdoor</SelectItem>
                      <SelectItem value="Client Office">Client Office</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-gray-300">Date</Label>
                  <Input
                    name="date"
                    type="date"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    required
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Time</Label>
                  <Input
                    name="time"
                    type="time"
                    className="bg-zinc-800/50 border-zinc-700 text-white focus:border-yellow-500/50"
                    required
                  />
                </div>
                <PremiumButton type="submit" className="w-full">
                  Schedule Shoot
                </PremiumButton>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-4">
        {shoots.map((shoot, index) => (
          <PremiumCard key={shoot.id} style={{ animationDelay: `${index * 100}ms` }}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-white">{shoot.client}</h3>
                    <Badge className="bg-blue-500/20 text-blue-400 border-0">Scheduled</Badge>
                  </div>
                  <p className="text-gray-400 mb-1">{shoot.type}</p>
                  <p className="text-sm text-gray-500">Location: {shoot.location}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-yellow-400">{shoot.time}</p>
                  <p className="text-sm text-gray-400">{new Date(shoot.date).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </PremiumCard>
        ))}
      </div>

      <PremiumCard>
        <CardHeader>
          <CardTitle className="text-yellow-400">Equipment Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { name: "Camera Kit A", status: "available", location: "Studio A" },
              { name: "Camera Kit B", status: "in-use", location: "Studio B" },
              { name: "Lighting Setup", status: "available", location: "Storage" },
              { name: "Audio Equipment", status: "maintenance", location: "Tech Room" },
              { name: "Drone Kit", status: "available", location: "Storage" },
              { name: "Backup Equipment", status: "available", location: "Storage" },
            ].map((equipment, index) => (
              <div
                key={index}
                className="p-4 bg-zinc-800/50 rounded-lg border border-zinc-700/50 hover:border-yellow-500/30 transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-white">{equipment.name}</h4>
                  <Badge
                    className={`border-0 ${
                      equipment.status === "available"
                        ? "bg-green-500/20 text-green-400"
                        : equipment.status === "in-use"
                          ? "bg-yellow-500/20 text-yellow-400"
                          : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {equipment.status}
                  </Badge>
                </div>
                <p className="text-sm text-gray-400">{equipment.location}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </PremiumCard>
    </div>
  )

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "dashboard":
        return renderDashboard()
      case "lead-management":
        return renderLeadManagement()
      case "sales-pipeline":
        return renderSalesPipeline()
      case "team-management":
        return renderTeamManagement()
      case "content-studio":
        return renderContentStudio()
      case "shoot-schedule":
        return renderShootSchedule()
      case "executive-view":
        return renderExecutiveView()
      default:
        return <div>Page Not Found</div>
    }
  }

  return (
    <div className="min-h-screen bg-black text-white flex relative overflow-hidden">
      <AnimatedBackground />
      <CursorFollower />

      <div className="w-64 bg-gradient-to-b from-zinc-900/95 via-zinc-800/90 to-zinc-900/95 border-r border-zinc-700/50 p-5 backdrop-blur-xl relative z-10 shadow-2xl">
        <div className="mb-8 pb-6 border-b border-zinc-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-lg flex items-center justify-center shadow-lg shadow-yellow-500/25 animate-pulse">
              <span className="text-black font-bold text-lg">G</span>
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                GOAT Media
              </h1>
              <p className="text-sm text-gray-400">Premium Hub</p>
            </div>
          </div>
        </div>

        <nav className="space-y-1">
          {[
            { id: "dashboard", label: "Dashboard", icon: BarChart3 },
            { id: "lead-management", label: "Lead Management", icon: Users },
            { id: "sales-pipeline", label: "Sales Pipeline", icon: TrendingUp },
            { id: "team-management", label: "Team Management", icon: UserCheck },
            { id: "content-studio", label: "Content Studio", icon: Film },
            { id: "shoot-schedule", label: "Shoot Schedule", icon: Calendar },
            { id: "executive-view", label: "Executive View", icon: DollarSign },
          ].map((item, index) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id as PageType)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left transition-all duration-300 border-l-4 group relative overflow-hidden ${
                  currentPage === item.id
                    ? "bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 text-yellow-400 border-l-yellow-400 shadow-lg shadow-yellow-500/20"
                    : "text-gray-400 hover:text-yellow-400 hover:bg-zinc-800/50 border-l-transparent hover:border-l-yellow-400/50 hover:shadow-lg hover:shadow-yellow-500/10"
                }`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <Icon className="w-4 h-4 group-hover:scale-110 transition-transform duration-200 relative z-10" />
                <span className="relative z-10">{item.label}</span>
              </button>
            )
          })}
        </nav>

        <div className="absolute bottom-5 left-5 right-5">
          <PremiumButton
            variant="outline"
            className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10 bg-transparent hover:border-red-400 hover:text-red-300"
            onClick={() => setIsAuthenticated(false)}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </PremiumButton>
        </div>
      </div>

      <div className="flex-1 p-8 relative z-10">
        <div className="bg-black/20 rounded-2xl p-6 backdrop-blur-sm border border-zinc-800/50 shadow-2xl min-h-full">
          {renderCurrentPage()}
        </div>
      </div>

      {notification && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-right duration-500">
          <PremiumCard
            className={`max-w-sm border-0 ${
              notification.type === "success"
                ? "bg-gradient-to-br from-green-900/80 to-green-800/60 border-green-500/30"
                : notification.type === "error"
                  ? "bg-gradient-to-br from-red-900/80 to-red-800/60 border-red-500/30"
                  : "bg-gradient-to-br from-blue-900/80 to-blue-800/60 border-blue-500/30"
            }`}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p
                    className={`font-medium ${
                      notification.type === "success"
                        ? "text-green-400"
                        : notification.type === "error"
                          ? "text-red-400"
                          : "text-blue-400"
                    }`}
                  >
                    {notification.type === "success" ? "Success" : notification.type === "error" ? "Error" : "Info"}
                  </p>
                  <p
                    className={`text-sm ${
                      notification.type === "success"
                        ? "text-green-200"
                        : notification.type === "error"
                          ? "text-red-200"
                          : "text-blue-200"
                    }`}
                  >
                    {notification.message}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setNotification(null)}
                  className={`${
                    notification.type === "success"
                      ? "text-green-400 hover:text-green-300 hover:bg-green-800/30"
                      : notification.type === "error"
                        ? "text-red-400 hover:text-red-300 hover:bg-red-800/30"
                        : "text-blue-400 hover:text-blue-300 hover:bg-blue-800/30"
                  }`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </PremiumCard>
        </div>
      )}
    </div>
  )
}

export default function GoatMediaHub() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  if (!isAuthenticated) {
    return <SignInPage onSignIn={() => setIsAuthenticated(true)} />
  }

  return <MainApp />
}
